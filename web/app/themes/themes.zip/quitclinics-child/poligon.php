







Enabled the re-subscription feature.

Now when the subscription expires, the user will be able to see the "re-subscribe" button in the subscription details.
This button will send to the checkout page.

To test this option, the subscription must expire.
You can force this.

To do this, you need to know the ID of the required subscription. In the admin panel, go to the Woocommerce menu to the Status page. On this page, open the "Scheduled Actions" tab.
(Woocommerce -> Status -> Scheduled Actions)

Then enter your subscription ID in the search box and search.

As a result, you will get the subscription you want. Then you will only need to click on the "Run" button under the name of the subscription.

Your subscription has now expired.

Next, on the account page, in the subscription details, a button will appear to repeat the subscription.
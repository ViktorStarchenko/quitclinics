
if(window.innerWidth <= 767){
    $('.icons_slider').slick({
        prevArrow: '<button id="prev" type="button" class="btn btn-juliet slider-arrow-prev"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>',
        nextArrow: '<button id="next" type="button" class="btn btn-juliet slider-arrow-next"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>',
    });
} else {

}
<?php /* Template Name: api2 */ ?>
<?php get_header(); ?>
<main id="content">
 <div class="wrapper-1240">
     <div id="root">
         <a href="#try-again" class="fancybox show-modal">MODAL</a>
     </div>
 </div>
    <div class="wrapper-1240">
        <?php the_content(); ?>
    </div>

</main>
<?php get_footer(); ?>